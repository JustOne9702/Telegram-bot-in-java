package org.example.bot;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class Newbot extends TelegramLongPollingBot
{



    @Override
    public void onUpdateReceived(Update update) {


        Message newmessage = update.getMessage();
          String newtext = newmessage.getText();
          Integer mesageId = newmessage.getMessageId();
          User user = newmessage.getFrom();
          System.out.println(" New message = " + newtext +" User = " + user.getLastName() + " MessageId = " + mesageId);
          SendMessage sendMessage = new SendMessage();
          sendMessage.setChatId(user.getId());
          sendMessage.setText("salom");
        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            throw new RuntimeException(e);
        }
    }



    @Override
    public String getBotUsername() {
        return "ESP_APIbot";
    }

    @Override
    public String getBotToken() {
        return "5904530515:AAH4UXBrwkeDrHw0CeR6_258wAF09gbpadk";
    }
}
